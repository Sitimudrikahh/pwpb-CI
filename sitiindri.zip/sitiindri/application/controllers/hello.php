<?php
class Hello extends CI_Controller{
  function index(){
    echo "Hai Persebaya Surabaya";
  }
  function show(){
    echo "I Make The world Better Place.";
  }
}
